<?php
require_once __DIR__ . '/../database/connection.php';
$db = new Database();
$conn = $db->conn;

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../index.php?page=armada');
    exit;
}

$merk   = trim($_POST['merk'] ?? '');
$plat   = strtoupper(trim($_POST['plat_nomor'] ?? ''));
$tahun  = (int)($_POST['tahun'] ?? 0);
$harga  = (float)($_POST['harga_per_hari'] ?? 0);
$status = $_POST['status'] ?? 'tersedia';
$owner  = (int)($_POST['owner_id'] ?? 0) ?: null;

if ($merk == '' || $plat == '' || $tahun < 1980 || $harga <= 0 || !in_array($status, ['tersedia', 'disewa', 'perawatan'])) {
    header('Location: ../index.php?page=armada-tambah&status=gagal&pesan=' . urlencode('Data tidak valid, periksa isian form.'));
    exit;
}

try {
    $stmt = $conn->prepare("INSERT INTO cars (owner_id, merk, plat_nomor, tahun, harga_per_hari, status) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param('issids', $owner, $merk, $plat, $tahun, $harga, $status);
    $stmt->execute();
    header('Location: ../index.php?page=armada&status=sukses&pesan=' . urlencode('Armada berhasil ditambahkan.'));
} catch (Exception $e) {
    $pesan = ($e->getCode() == 1062) ? 'Plat nomor sudah terdaftar.' : 'Gagal menyimpan: ' . $e->getMessage();
    header('Location: ../index.php?page=armada-tambah&status=gagal&pesan=' . urlencode($pesan));
}
exit;