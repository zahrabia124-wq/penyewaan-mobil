<?php
// Form tambah denda.
// Denda hanya bisa diberikan pada sewa yang sudah disetujui / selesai.
$sewa = $conn->query("SELECT rentals.id, rentals.nama_penyewa, cars.merk, cars.plat_nomor
                      FROM rentals
                      JOIN cars ON cars.id = rentals.car_id
                      WHERE rentals.status = 'disetujui' OR rentals.status = 'selesai'
                      ORDER BY rentals.id DESC");
?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Tambah Denda</h1>
    <a href="index.php?page=denda" class="btn btn-sm btn-secondary">Kembali</a>
</div>

<div class="card shadow mb-4">
    <div class="card-body">
        <form action="function/denda_insert.php" method="POST">

            <div class="form-group">
                <label>Sewa</label>
                <select name="rental_id" class="form-control" required>
                    <option value="">-- Pilih sewa --</option>
                    <?php while ($s = $sewa->fetch_assoc()) { ?>
                        <option value="<?php echo $s['id']; ?>">
                            #<?php echo $s['id']; ?> - <?php echo htmlspecialchars($s['nama_penyewa']); ?>
                            - <?php echo htmlspecialchars($s['merk']); ?> (<?php echo htmlspecialchars($s['plat_nomor']); ?>)
                        </option>
                    <?php } ?>
                </select>
            </div>

            <div class="form-group">
                <label>Jenis Denda</label>
                <select name="jenis" class="form-control" required>
                    <option value="Terlambat">Terlambat</option>
                    <option value="Kerusakan">Kerusakan</option>
                    <option value="Kehilangan">Kehilangan</option>
                    <option value="Lainnya">Lainnya</option>
                </select>
            </div>

            <div class="form-group">
                <label>Jumlah (Rp)</label>
                <input type="number" name="jumlah" class="form-control" min="1" required>
            </div>

            <div class="form-group">
                <label>Keterangan</label>
                <textarea name="keterangan" class="form-control" rows="3"></textarea>
            </div>

            <button type="submit" class="btn btn-primary">Simpan</button>
        </form>
    </div>
</div>