<?php
// Form terbitkan invoice.
// Yang muncul hanya sewa yang sudah disetujui / selesai DAN belum punya invoice.
// (Bagian "NOT IN (SELECT rental_id FROM invoices)" artinya: id sewa tidak ada di tabel invoices)
$sewa = $conn->query("SELECT rentals.id, rentals.nama_penyewa, rentals.total_harga, cars.merk, cars.plat_nomor
                      FROM rentals
                      JOIN cars ON cars.id = rentals.car_id
                      WHERE (rentals.status = 'disetujui' OR rentals.status = 'selesai')
                      AND rentals.id NOT IN (SELECT rental_id FROM invoices)
                      ORDER BY rentals.id DESC");
?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Terbitkan Invoice</h1>
    <a href="index.php?page=invoice" class="btn btn-sm btn-secondary">Kembali</a>
</div>

<div class="card shadow mb-4">
    <div class="card-body">
        <form action="function/invoice_insert.php" method="POST">

            <div class="form-group">
                <label>Sewa</label>
                <select name="rental_id" class="form-control" required>
                    <option value="">-- Pilih sewa --</option>
                    <?php while ($s = $sewa->fetch_assoc()) { ?>
                        <option value="<?php echo $s['id']; ?>">
                            #<?php echo $s['id']; ?> - <?php echo htmlspecialchars($s['nama_penyewa']); ?>
                            - <?php echo htmlspecialchars($s['merk']); ?> (<?php echo htmlspecialchars($s['plat_nomor']); ?>)
                            - Sewa Rp <?php echo number_format($s['total_harga'], 0, ',', '.'); ?>
                        </option>
                    <?php } ?>
                </select>
            </div>

            <div class="form-group">
                <label>Catatan (boleh kosong)</label>
                <textarea name="catatan" class="form-control" rows="3"></textarea>
            </div>

            <p class="text-muted">Total tagihan = total sewa + semua denda pada sewa tersebut (dihitung otomatis).</p>

            <button type="submit" class="btn btn-primary">Terbitkan</button>
        </form>
    </div>
</div>