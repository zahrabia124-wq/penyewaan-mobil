<?php
// Halaman daftar invoice.
$hasil = $conn->query("SELECT fines.*, users.nama AS nama_penyewa, cars.merk, cars.plat_nomor
                       FROM fines
                       JOIN rentals ON rentals.id = fines.rental_id
                       JOIN users ON users.id = rentals.user_id
                       JOIN cars ON cars.id = rentals.car_id
                       ORDER BY fines.id DESC");
?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Terbitkan Invoice</h1>
    <a href="index.php?page=invoice-tambah" class="btn btn-sm btn-primary">+ Terbitkan Invoice</a>
</div>

<div class="card shadow mb-4">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>No. Invoice</th>
                        <th>Penyewa</th>
                        <th>Mobil</th>
                        <th>Tanggal Terbit</th>
                        <th>Total Tagihan</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $hasil->fetch_assoc()) { ?>

                        <?php
                        if ($row['status_bayar'] == 'lunas') {
                            $warna = 'success';
                            $teks  = 'Lunas';
                        } else {
                            $warna = 'warning';
                            $teks  = 'Belum bayar';
                        }
                        ?>

                        <tr>
                            <td><?php echo $row['no_invoice']; ?></td>
                            <td><?php echo htmlspecialchars($row['nama_penyewa']); ?></td>
                            <td><?php echo htmlspecialchars($row['merk']); ?> - <?php echo htmlspecialchars($row['plat_nomor']); ?></td>
                            <td><?php echo date('d/m/Y', strtotime($row['tanggal_terbit'])); ?></td>
                            <td>Rp <?php echo number_format($row['total_tagihan'], 0, ',', '.'); ?></td>
                            <td><span class="badge badge-<?php echo $warna; ?>"><?php echo $teks; ?></span></td>
                            <td>
                                <a href="index.php?page=invoice-edit&id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">Edit</a>

                                <form action="function/invoice_delete.php" method="POST" style="display:inline"
                                      onsubmit="return confirm('Yakin hapus invoice ini?')">
                                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                    <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                                </form>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>