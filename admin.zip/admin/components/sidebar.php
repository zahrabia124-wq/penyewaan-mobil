<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
          <div class="sidebar-brand-icon rotate-n-15">
              <i class="fas fa-laugh-wink"></i>
          </div>
          <div class="sidebar-brand-text mx-3">Penyewaan & Rental Mobil</sup></div>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item <?= $page === 'dashboard' ? 'active' : '' ?>">
          <a class="nav-link" href="index.php">
              <i class="fas fa-fw fa-tachometer-alt"></i>
              <span>Dashboard</span></a>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Heading -->
      <div class="sidebar-heading">
          Interface
      </div>

      <!-- Nav Item - Kelola Armada -->
      <li class="nav-item <?= strpos($page, 'armada') === 0 ? 'active' : '' ?>">
          <a class="nav-link" href="index.php?page=armada">
              <i class="fas fa-fw fa-car"></i>
              <span>Kelola Armada</span></a>
      </li>

      <!-- Nav Item - Pengajuan Sewa -->
      <li class="nav-item <?= strpos($page, 'sewa') === 0 ? 'active' : '' ?>">
          <a class="nav-link" href="index.php?page=sewa">
              <i class="fas fa-fw fa-key"></i>
              <span>Pengajuan Sewa</span></a>
      </li>

      <!-- Nav Item - Denda -->
      <li class="nav-item <?= strpos($page, 'denda') === 0 ? 'active' : '' ?>">
          <a class="nav-link" href="index.php?page=denda">
              <i class="fas fa-fw fa-exclamation-triangle"></i>
              <span>Denda</span></a>
      </li>

      <!-- Nav Item - Terbitkan Invoice -->
      <li class="nav-item <?= strpos($page, 'invoice') === 0 ? 'active' : '' ?>">
          <a class="nav-link" href="index.php?page=invoice">
              <i class="fas fa-fw fa-file-invoice-dollar"></i>
              <span>Terbitkan Invoice</span></a>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">

      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
          <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

      <!-- Sidebar Message -->
      <div class="sidebar-card d-none d-lg-flex">
          <img class="sidebar-card-illustration mb-2" src="img/undraw_rocket.svg" alt="...">
          <p class="text-center mb-2"><strong>SB Admin Pro</strong> is packed with premium features, components, and more!</p>
          <a class="btn btn-success btn-sm" href="https://startbootstrap.com/theme/sb-admin-pro">Upgrade to Pro!</a>
      </div>

  </ul>